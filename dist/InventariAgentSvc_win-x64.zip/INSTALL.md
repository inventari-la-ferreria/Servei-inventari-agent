# Instalación de InventariAgentSvc (Windows)

Este paquete contiene el servicio InventariAgent listo para instalar en otro PC.

## Requisitos
- Windows 10/11 o Windows Server.
- .NET Runtime 8.0 instalado (si no se publicó como self-contained).
- Credenciales de Firebase (archivo `firebase-credentials.json`).

## Pasos de instalación
1. Copia la carpeta completa `InventariAgentSvc` a la máquina destino (por ejemplo a `C:\Temp\InventariAgentSvc`).
2. (Opcional) Coloca `firebase-credentials.json` junto al `install.ps1` si quieres que el instalador lo copie automáticamente a `C:\ProgramData\InventariAgent\firebase-credentials.json`.
3. Abre PowerShell como Administrador en esa carpeta y ejecuta:
   ```powershell
   Set-ExecutionPolicy Bypass -Scope Process -Force
   .\install.ps1
   ```
4. El script copiará los binarios a `C:\Program Files\InventariAgent`, creará el servicio `InventariAgent` e intentará iniciarlo.

## Configuración
- El agente guarda su configuración en `C:\ProgramData\InventariAgent\config.json`.
- La primera vez se crea automáticamente con valores por defecto. Edita `DeviceId`/`DeviceName` según corresponda y reinicia el servicio.
- Umbrales por defecto de temperatura: Warn 85°C, Critical 95°C (CPU y GPU). Se pueden ajustar en `config.json` dentro de `Thresholds`.
- Política anti-spam de incidencias:
  - NewIncidentCooldownMinutes = 120
  - RepeatUpdateCooldownMinutes = 60

## Actualización / Reinstalación
- Vuelve a ejecutar `install.ps1`. El script detendrá y eliminará el servicio si ya existe y copiará los nuevos archivos.

## Desinstalación manual
1. Parar el servicio:
   ```powershell
   Stop-Service InventariAgent
   ```
2. Eliminar el servicio:
   ```powershell
   sc.exe delete InventariAgent
   ```
3. (Opcional) Borrar carpetas:
   - `C:\Program Files\InventariAgent`
   - `C:\ProgramData\InventariAgent`

## Logs y solución de problemas
- Revisa el Visor de eventos de Windows (Application) y archivos de log si los configuras.
- Asegúrate de que `firebase-credentials.json` exista en `C:\ProgramData\InventariAgent` y sea válido.
- Verifica conectividad a Internet para Firestore.
